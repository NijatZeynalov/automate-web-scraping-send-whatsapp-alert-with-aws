
__version_info__ = ('7', '16', '0')
__version__ = '.'.join(__version_info__)
